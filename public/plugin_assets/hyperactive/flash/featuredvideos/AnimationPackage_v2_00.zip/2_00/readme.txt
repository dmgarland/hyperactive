If you don't know how to setup an ActionScript 2.0 project, take 
a look into the "empty_setup.fla". There is a comment in the 
first frame of the "actions" timeline. Then, please take a look 
into docs under support.htm for further information.

AnimationPackage.flp is a Flash MX 2004 project file. This is 
is just for your convenience and is not needed to setup an 
ActionScript 2.0 project. See your Flash manual.

When you're using Flex you can drop the animationpackage.swc component 
into your WEB-INF>flex>user_classes folder.